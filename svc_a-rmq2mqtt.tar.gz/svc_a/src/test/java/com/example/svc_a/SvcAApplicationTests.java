package com.example.svc_a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SvcAApplicationTests {

	@Test
	void contextLoads() {
	}

}
