package com.example.svc_b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SvcBApplicationTests {

	@Test
	void contextLoads() {
	}

}
